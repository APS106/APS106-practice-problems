class Robot:
    """ An object that can localize itself"""
    
    def __init__(self, map):
        """ 
        Initialize map
        (self, list of str) -> None
        """
        self.map = map
        self.possible_locations = set(range(len(map))) 
        
               
    def move(self):
        '''
        (self) -> None
        Move the robot one step to the right, maintaining the set of 
        possible locations
        '''
        print("*** MOVE ***")

        new_locations = set()
        # Increment each possible location by 1 as long as we don't run
        # off the map
        for loc in self.possible_locations:
            loc += 1
            if loc >= len(self.map): # assume the map wraps around
                loc = 0
            new_locations.add(loc)                
                
        self.possible_locations = new_locations    

    def sense(self):
        """
        (self) -> str
        Prompt user for measurement at current state and return it
        (In a real application, this method would reading from the sensor)
        """
        invalid_input = True
        while(invalid_input):
            sensor_value = input("Enter observed colour (white/black): ")
            if sensor_value == 'white' or sensor_value == 'black':
                invalid_input = False
            else:
                print("Invalid entry")

        return sensor_value
    
    def localize(self, sensor_value):
        """
        (self, str) -> None
        Examine all the possible locations and remove those that are
        not consistent with sensor_value
        """
        # self.possible_locations contains the set of possible locations
        # given the new sensor_value remove any of the elements of the list
        # that can no longer be the current position
        new_locations = set()
        for loc in self.possible_locations:
            if self.map[loc] == sensor_value:
                new_locations.add(loc)
        
        self.possible_locations = new_locations

    def has_possible_locations(self):
        """
        (self) -> bool
        Return True if the robot has at least one location where it could be
        """
        return self.possible_locations

    def is_localized(self):
        """
        (self) -> bool
        Return True if the robot has only one location where it could be
        """
        return len(self.possible_locations) == 1

    def __str__(self):
        """
        (self)->str
        Return information about the state of the Robot in a string
        """
        s = "-------------\n"
        if self.is_localized():
            s += "\nLocalized at position: " + str(self.possible_locations) + "\n"
        else:
            s += "Not localized. Possible locations: " + str(self.possible_locations) + \
            "\n-------------\n"      
        return s

# initialize map of the world
world_map = ['white','black','black','white','white','black','white','black','black',
       'black','black','white','white','black','white','white','black','white',
       'black','white','white','black','black','white','black','white','black']

print("The map looks like this: ", world_map)
print("\nPick a location for the robot (but keep it secret).")

# create localization instance
robot = Robot(world_map)

print("Before doing anything")
print(robot)

sensor_value = robot.sense()
robot.localize(sensor_value)
print(robot)

while(robot.has_possible_locations() and not robot.is_localized()):
    robot.move()
    sensor_value = robot.sense()
    robot.localize(sensor_value)
    print(robot)

if (not robot.has_possible_locations()):
    print("Something went wrong")
else:
    print("Success! The robot is at position: ", robot.possible_locations)
