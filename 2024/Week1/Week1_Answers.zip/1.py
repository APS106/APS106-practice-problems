# A simple program to print a message to the screen

print("I'm going to love this course")
