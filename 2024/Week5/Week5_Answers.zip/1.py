
#1 Read one string from the user. Then, swap cases and print the result. 
# In other words, convert all lowercase letters to uppercase letters and 
# vice versa. 
# You should solve this question three times.
# a) There is a str method that will do this for you and so after the input 
#    just call it.
# b) But a) is not much of an exercise, so you should also do it without 
#    calling that function!
# c) Now do it without any string functions at all (Hint: ord/chr).

s = input("Please input a string with upper and lower case letters: ")

# a. Do it with the str method swapcase
swap_s = s.swapcase()
print(swap_s)

# b. Now do it "by hand" without calling swapcase
swap_s = ""
i = 0
while i < len(s):
    ch = s[i]
    if ch.islower():
        new_ch = ch.upper()
    else:
        new_ch = ch.lower()
        
    swap_s += new_ch
    i += 1

print(swap_s)

# c. Now with no str methods
swap_s = ""
i = 0
upper_to_lower_conversion = ord('A') - ord('a')
while i < len(s):
    ch = s[i]
    if ord('a') <= ord(ch) <= ord('z'):
        new_ch = chr(ord(ch) + upper_to_lower_conversion)
    elif ord('A') <= ord(ch) <= ord('Z'):
        new_ch = chr(ord(ch) - upper_to_lower_conversion)
    else:
        new_ch = ch # not a letter
                    # Why to I need an if-elif-else here but not above?
        
    swap_s += new_ch
    i += 1

print(swap_s)