# Collatz Conjecture

# The Collatz Conjecture (https://en.wikipedia.org/wiki/Collatz_conjecture) 
# is based on a sequence of numbers generated with the following rules:
#	start with an arbitrary positive number c_0
#	if c_i is even then c_(i+1)= c_i/2
#	if c_i is odd then c_(i+1)= 〖3c〗_i+1

# The Collatz Conjecture states that this sequence will eventually produce 1. 
# That is c_j=1 for some non-infinite value of j.

# Write a function to test the Collatz Conjecture. 
# Your function should accept a value for c_0 and return the minimum 
# number, j, such that c_j=1.

def collatz(c0):
    '''
    (int) -> int
    
    Follow the rules of the Collatz Conjecture to return the lowest index of
    the sequence starting with c0 s.t. cj == 1
    '''
    j = 0
    c = c0
    
    while c != 1:
        if c % 2 == 0:
            c = c//2
        else:
            c = 3 * c + 1
            
        j += 1
        
        #print(j, c)
        
    return j


#print(collatz(21))
#print(collatz(3))
#print(collatz(2))

s = 1
num_with_max_j = -1
max_j = -1

while s <= 100000:
    j = collatz(s)
    #print(s, j)
    
    if j > max_j:
        max_j = j
        num_with_max_j = s
        
    s += 1
    
print(num_with_max_j, max_j)