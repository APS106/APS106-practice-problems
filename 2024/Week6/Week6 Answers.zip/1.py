
#1 Read one string from the user. Then, swap cases and print the result. 
# In other words, convert all lowercase letters to uppercase letters and 
# vice versa. 
# You should solve this question twice.
# a) There is a str method that will do this for you and so after the input 
#    just call it.
# b) But a) is not much of an exercise, so you should also do it without 
#    calling that function!

s = input("Please input a string with upper and lower case letters: ")

# a. Do it with the str method swapcase
swap_s = s.swapcase()
print(swap_s)

# b. Now do it "by hand" without calling swapcase
swap_s = ""
i = 0
for ch in s:
    if ch.islower():
        new_ch = ch.upper()
    else:
        new_ch = ch.lower()
        
    swap_s += new_ch

print(swap_s)

# c. Now with no str methods
swap_s = ""
i = 0
upper_to_lower_conversion = ord('A') - ord('a')
for ch in s:

    if ord('a') <= ord(ch) <= ord('z'):
        new_ch = chr(ord(ch) + upper_to_lower_conversion)
    elif ord('A') <= ord(ch) <= ord('Z'):
        new_ch = chr(ord(ch) - upper_to_lower_conversion)
    else:
        new_ch = ch # not a letter
                    # Why to I need an else case here but not above?
        
    swap_s += new_ch

print(swap_s)

