# Real Estate using a list

# A small application to print out the housing information for
# houses on a set of streets entered by the user.

import csv

def print_house(house):
    # display showing house address, size and price
    # Entries are: number, street, type, size, floors, bedrooms, bathrooms, 
    #              lot-size, parking, facing, age, taxes, price

    print("Address:", house[0], house[1], "Size:",
          house[3], "Price:", house[-1])


def get_MLS_data(filename):
    '''
    (str)->list of lists of string
    Opens <filename> as a CSV file, reads in each row and returns the list of rows
    '''
    
    # read in the database
    MLS_data = [] 
    with open(filename, 'r') as csvfile:
        real_estate_reader = csv.reader(csvfile)

        for row in real_estate_reader:
            MLS_data.append(row)
            
    return MLS_data

def get_street_queries():
    '''
    None -> set of strings
    Prompts user to enter street names to query database
    '''
    street_set = set()

    street = input("Enter a street name (type exit to end): ")
    while street != "exit":
        street_set.add(street)
        street = input("Enter a street name (type exit to end): ")
        
    return street_set

def process_queries(streets, MLS):
    '''
    (set of str, lists of list) -> None
    Looks up each entry in streets in MLS and prints the house info or an error message
    '''
    MLS_street_index = 1
    for street in street_set:
        print("Houses on", street)  
        found_house = False        # this is the "flag"
        for house in MLS_data:
            if house[MLS_street_index] == street:
                print_house(house)
                found_house = True
                
        if not found_house:  # if the flag hasn't been reset, then we didn't find a house
            print("No houses on", street)

 
# *** Main code ***

# Read in MLS data and convert to dictionary
MLS_data = get_MLS_data("real_estate.csv")

# Get the streets from the user and store them in a set
street_set = get_street_queries()

# Run the queries on the MLS database
process_queries(street_set, MLS_data) 