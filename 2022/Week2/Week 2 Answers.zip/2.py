# Write a program that defines two integers, one being the 
# largest 3 digit number and one being the smallest 5 digit number.
# Then, print these two values, and their sum onto the screen.

largest_three_digit = 999
smallest_five_digit = 10000

sum = largest_three_digit + smallest_five_digit

print("Largest three digit integer:", largest_three_digit)
print("Smallest five digid integer:", smallest_five_digit)

print("Sum of the Two:", sum)
